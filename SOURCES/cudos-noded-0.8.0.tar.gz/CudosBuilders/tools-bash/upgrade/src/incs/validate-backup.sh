#!/bin/bash -i

source "$WORKING_SRC_DIR/incs/validate-params.sh"

source "$WORKING_SRC_DIR/incs/validate-network.sh"

source "$WORKING_SRC_DIR/incs/validate-folders.sh"

