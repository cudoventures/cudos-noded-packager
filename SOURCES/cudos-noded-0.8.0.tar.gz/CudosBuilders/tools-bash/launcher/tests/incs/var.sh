EXPORTED_GENESIS="$WORKING_DIR/exports/genesis.json"
BASE_GENESIS="$WORKING_DIR/tests/config/genesis.root.json"
STAKING_JSON="$WORKING_DIR/tests/config/staking.json"
tmpExportedAddressespath="/tmp/tmpExportedAddresses.json"
