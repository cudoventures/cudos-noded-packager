**Outdated!**
=

# Deployer monitoring - overview

The setup uses prometheus, grafana and cosmos-exporter to set up monitoring of the nodes of the network and to all the validators liveness in the network

# Configure

Please refer to these [docs](../readme.md#configure)

# List of npm commands regarding this deployer:

All of the NPM commands below are available once you navigate to <code>parentDir/CudosBuilders/tools-nodejs</code> directory.

**<code>deploy--monitoring-testnet-public</code>** - deploys the monitoring to the public testnet using <code>secrets.json</code> in the deployer's folder.
