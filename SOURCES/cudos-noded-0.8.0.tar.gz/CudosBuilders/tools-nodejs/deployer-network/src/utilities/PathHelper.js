const path = require('path');

class PathHelper {

    static WORKING_DIR = path.join(__dirname, '..', '..', '..', '..', '..');

}

module.exports = PathHelper;