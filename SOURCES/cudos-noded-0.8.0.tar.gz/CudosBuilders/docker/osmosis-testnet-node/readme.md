# You can get the latest snapshot link from here:
    https://mp20.net/snapshots/osmosis-testnet/

# You can get the seed node from here:
    https://osmosis-labs.github.io/osmosis/developing/network/join-testnet.html#update-cosmovisor-to-v6