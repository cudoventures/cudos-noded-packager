# Local development
Collection of bash scripts to help with manual tests. Not for production.  